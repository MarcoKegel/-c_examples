# Import von Bibliotheken
from threading import Timer, Thread
import RPi.GPIO as GPIO
import time
import sys
# eine Klasse welche einen zurueckstellbaren Timer als Thread erstellt
class ResetTimer(object):
	def __init__(self, time, function, daemon=None):
		self.__time = time
		self.__function = function
		self.__set()
		self.__running = False
		self.__killed = False
		Thread.__init__(self)
		self.__daemon = daemon
	def __set(self):
		self.__timer = Timer(self.__time, self.__function)
	def stop(self):
		self.__daemon = True
	def run(self):
		self.__running = True
		self.__timer.start()
		if self.__daemon == True:
			sys.exit(0)
	def cancel(self):
		self.__running = False
		self.__timer.cancel()
	def reset(self, start = False):
		if self.__running:
			self.__timer.cancel()
		self.__set()
		if self.__running or start:
			self.start()
# Methode die zaehlt wie oft die Lichtschranke ausloest
def count(self):
	global counter
	counter = counter + 1
# Methode zur Berechnung / Ausgabe der Drehzahl
def output():
	global counter
	timer.cancel() # stoppen des Timers
	speed = int(((counter/2)*calc)/wheel) # Berechnung der Drehzahl pro Minute
	print("Drehzahl pro Minute: " + str(speed)) # Ausgabe
	counter = 0 # Zuruecksetzung des Zaehlers
	timer.reset() # Zuruecksetzen des Timers
	timer.run() # Timer erneut starten
# Setzen der Variablen
counter = 0
pin = 4 # Pinbelegung
interval = 10.0 #Intervall von 10 Sekunden
calc = 60 / int(interval) # Intervall auf 1 Minute hoch rechnen
wheel = 20 # Anzahl der Loecher im Rad
GPIO.setmode(GPIO.BCM)
GPIO.setup(pin,GPIO.IN)
# Erstellung des Timers welcher die Methode output nach interval Sekunden # ausfuehrt
timer = ResetTimer(interval, output)
# Hauptprogramm
try:
	# fuehrt Methode count aus wenn die Spannung faellt
	GPIO.add_event_detect(pin, GPIO.FALLING,count)
	# Timer startet
	timer.run()
except KeyboardInterrupt:
	timer.stop()
	timer.join()
	GPIO.cleanup()
